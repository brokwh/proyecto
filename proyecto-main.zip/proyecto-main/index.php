<!DOCTYPE html>
<html lang="es">
<head>
<title>Santa Comandas</title>
<?php include("includes/header.php");?>
    
    <?php require_once("controllers/loginController.php"); ?>
    <?php // require_once("controllers/ListadoProductoController.php"); ?>

 <!--final body -->
<?php include("includes/footer.php"); ?>