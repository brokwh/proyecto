<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
           <div class="container-fluid">
    <a class="navbar-brand" href="http://localhost/proyecto/home.php">SANTA - COMANDAS</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href=""></a>
        </li>

       <!-- <li class="nav-item">
          <a class="nav-link"  href="http://localhost/proyecto/views/productoView.php">Productos</a>
        </li>
        <li class="nav-item">

          <a class="nav-link" href="#">Borrar</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Buscar</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Modificar</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Borrar todo</a>
        </li> 
      -->
        
        
      </ul>
    </div>
    <div class="navbar-nav ms-auto">
        <form action="">
                <a href="http://localhost/proyecto/index.php" class="nav-item nav-link">Ingresar</a>
          </form>
    </div>
  </div>
</nav>